BUILT / THOUGHT image assets extracted from the supplied 8-page PDF.
Place all .webp files in the repository at public/images/.

art-workshop-01.webp, art-workshop-02.webp, sculpture-01.webp, sculpture-02.webp,
art-painting-portrait.webp, art-paintings-01.webp, art-paintings-02.webp -> Art & Sculpture
prosthetic-arm-bike.webp, prosthetic-arm-use.webp, prosthetics-rehabilitation.webp,
prosthetic-component.webp -> Prosthetics and Rehabilitation
beer-lambert-cuvettes-01.webp, beer-lambert-cuvettes-02.webp,
beer-lambert-cuvettes-03.webp -> Spectroscopy / Modified Beer-Lambert Law
gilboa-gradcam.webp -> Gilboa Labs CNN / Grad-CAM
ban-concept-sketch.webp, ban-ansys-valve.webp -> Breath-actuated nebuliser
dpi-copper-electrode-traces.webp -> Electrodynamic DPI prototypes
autopep-chest-wall-feedback-rig.webp -> AutoPep chest-wall feedback test rig
fitbit-display-teardown.webp -> Early hardware experiments
